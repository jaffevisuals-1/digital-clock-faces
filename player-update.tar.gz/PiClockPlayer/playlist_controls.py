from __future__ import annotations


def shifted_index(current: int, count: int, offset: int) -> int:
    """Move through a circular playlist without ever leaving its bounds."""
    if count <= 0:
        return 0
    return (current + offset) % count
