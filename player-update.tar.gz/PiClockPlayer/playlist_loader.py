from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any


DEFAULT_LIBRARY_DIR = Path.home() / "clock-player" / "library"

DEFAULT_SETTINGS: dict[str, Any] = {
    "showHands": True,
    "handColor": "#ffffff",
    "handThickness": 8,
    "handStyle": "classic",
    "markerMode": "dashes",
    "markerColor": "#ffffff",
    "markerVariant": "classic",
    "markerWeight": 4,
    "dateColor": "#ffffff",
    "dateVariant": "classic",
    "dateWeight": 6,
}


@dataclass(frozen=True)
class ClockDesign:
    id: str
    name: str
    duration_minutes: int
    clock_video: Path | None
    date_video: Path | None
    font_file: Path | None
    settings: dict[str, Any]


@dataclass(frozen=True)
class Playlist:
    version: int
    updated_at: str
    designs: list[ClockDesign]


def _as_int(value: Any, fallback: int) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return fallback


def _resolve_media(library_dir: Path, value: Any) -> Path | None:
    if not value:
        return None
    path = (library_dir / str(value)).resolve()
    try:
        path.relative_to(library_dir.resolve())
    except ValueError:
        return None
    return path if path.exists() else None


def load_playlist(library_dir: Path = DEFAULT_LIBRARY_DIR) -> Playlist:
    manifest_path = library_dir / "playlist.json"
    if not manifest_path.exists():
        return Playlist(version=0, updated_at="", designs=[])

    data = json.loads(manifest_path.read_text(encoding="utf-8"))
    by_id = {str(design.get("id")): design for design in data.get("designs", [])}
    order = data.get("designOrder") or list(by_id)
    designs: list[ClockDesign] = []

    for design_id in order:
        raw = by_id.get(str(design_id))
        if not raw:
            continue

        settings = {**DEFAULT_SETTINGS, **(raw.get("settings") or {})}
        duration = max(1, _as_int(raw.get("durationMinutes"), 30))
        designs.append(
            ClockDesign(
                id=str(raw.get("id") or design_id),
                name=str(raw.get("name") or "Clock Face"),
                duration_minutes=duration,
                clock_video=_resolve_media(library_dir, raw.get("clockVideo")),
                date_video=_resolve_media(library_dir, raw.get("dateVideo")),
                font_file=_resolve_media(library_dir, raw.get("fontFile")),
                settings=settings,
            )
        )

    return Playlist(
        version=max(0, _as_int(data.get("version"), 0)),
        updated_at=str(data.get("updatedAt") or ""),
        designs=designs,
    )


def playlist_is_newer(candidate: Playlist, current: Playlist) -> bool:
    if candidate.version != current.version:
        return candidate.version > current.version
    return candidate.updated_at > current.updated_at
