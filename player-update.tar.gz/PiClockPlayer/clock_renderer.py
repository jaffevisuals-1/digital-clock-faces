from __future__ import annotations

import os
import hashlib
from pathlib import Path
from typing import Any

from kivy.clock import Clock
from kivy.core.image import Image as CoreImage
from kivy.core.text import LabelBase
from kivy.graphics import Color, Ellipse, Line, Rectangle
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.label import Label

from clock_time import clock_now, clock_vector_for_degrees, hand_degrees_for_time
from playlist_loader import ClockDesign, DEFAULT_SETTINGS


_REGISTERED_FONTS: dict[Path, str] = {}


def register_design_font(path: Path | None) -> str:
    if path is None:
        return "Roboto"
    resolved = path.resolve()
    if resolved not in _REGISTERED_FONTS:
        name = f"ClockFont{hashlib.sha1(str(resolved).encode('utf-8')).hexdigest()[:12]}"
        LabelBase.register(name=name, fn_regular=str(resolved))
        _REGISTERED_FONTS[resolved] = name
    return _REGISTERED_FONTS[resolved]


def hex_to_rgba(value: str, alpha: float = 1.0) -> tuple[float, float, float, float]:
    raw = str(value or "#ffffff").strip().lstrip("#")
    if len(raw) == 3:
        raw = "".join(ch * 2 for ch in raw)
    if len(raw) != 6:
        raw = "ffffff"
    return tuple(int(raw[index : index + 2], 16) / 255 for index in (0, 2, 4)) + (alpha,)


class ClockFace(FloatLayout):
    def __init__(self, **kwargs: Any) -> None:
        kwargs.setdefault("size_hint", (None, None))
        super().__init__(**kwargs)
        self.settings = dict(DEFAULT_SETTINGS)
        self.number_labels: list[Label] = []

        # Graphics instructions remain attached for the widget's lifetime. Only
        # their coordinates change, avoiding blank frames between redraws.
        with self.canvas.before:
            self._video_color = Color(1, 1, 1, 1)
            self._video_face = Ellipse(pos=self.pos, size=self.size)
            self._face_color = Color(0.05, 0.06, 0.08, 1)
            self._face = Ellipse(pos=self.pos, size=self.size)

        # Keep every functional clock element above the Video child. Some Pi
        # video providers paint an opaque black frame while opening a stream,
        # even when their hidden decoding widget has zero opacity.
        with self.canvas.after:
            self._outer_color = Color(1, 1, 1, 0.12)
            self._outer_ring = Line(circle=(0, 0, 0), width=2)
            self._inner_color = Color(1, 1, 1, 0.055)
            self._inner_ring = Line(circle=(0, 0, 0), width=1)
            self._marker_color = Color(1, 1, 1, 1)
            self._marker_lines = [Line(points=[0, 0, 0, 0], width=2) for _ in range(12)]
            self._hand_color = Color(1, 1, 1, 1)
            self._hour_hand = Line(points=[0, 0, 0, 0], width=8)
            self._minute_hand = Line(points=[0, 0, 0, 0], width=6)
            self._second_hand = Line(points=[0, 0, 0, 0], width=3)
            self._center_dot = Ellipse(pos=(0, 0), size=(0, 0))

        for hour in range(1, 13):
            label = Label(text=str(hour), bold=True, size_hint=(None, None), opacity=0)
            self.add_widget(label)
            self.number_labels.append(label)

        self._center = (0.0, 0.0)
        self._radius = 0.0
        self.animated_face: CoreImage | None = None
        self._video_ready = False
        self.bind(pos=self._redraw_geometry, size=self._redraw_geometry)
        Clock.schedule_interval(self._update_time, 0.1)
        Clock.schedule_once(self._redraw_geometry, 0)

    def set_settings(self, settings: dict[str, Any]) -> None:
        self.settings = {**DEFAULT_SETTINGS, **settings}
        self._redraw_geometry()

    def set_design(self, design: ClockDesign) -> None:
        self._set_video(design.clock_video)
        font_name = register_design_font(design.font_file)
        for label in self.number_labels:
            label.font_name = font_name
        self.set_settings(design.settings)

    def set_default(self) -> None:
        self._set_video(None)
        for label in self.number_labels:
            label.font_name = "Roboto"
        self.set_settings(DEFAULT_SETTINGS)

    def _redraw_geometry(self, *_args: Any) -> None:
        width, height = self.size
        if width <= 0 or height <= 0:
            return

        cx = self.x + width / 2
        cy = self.y + height / 2
        radius = min(width, height) * 0.45
        marker_mode = self.settings.get("markerMode")
        marker_color = hex_to_rgba(self.settings.get("markerColor", "#ffffff"))
        marker_weight = max(1, int(self.settings.get("markerWeight", 4)))
        variant_scale = {
            "classic": 1.0,
            "fine": 0.62,
            "bold": 1.34,
            "rounded": 1.08,
        }.get(str(self.settings.get("markerVariant")), 1.0)

        self._center = (cx, cy)
        self._radius = radius
        self._face.pos = self.pos
        self._face.size = self.size
        self._video_face.pos = self.pos
        self._video_face.size = self.size
        self._outer_ring.circle = (cx, cy, min(width, height) * 0.49)
        self._inner_ring.circle = (cx, cy, min(width, height) * 0.38)
        marker_alpha = marker_color[3] if marker_mode == "dashes" else 0
        self._marker_color.rgba = (*marker_color[:3], marker_alpha)

        line_width = max(1, marker_weight * 0.8 * variant_scale)
        inner = radius * 0.86
        outer = radius * 0.99
        for index, marker_line in enumerate(self._marker_lines):
            vector_x, vector_y = clock_vector_for_degrees(index * 30)
            marker_line.points = [
                cx + vector_x * inner,
                cy + vector_y * inner,
                cx + vector_x * outer,
                cy + vector_y * outer,
            ]
            marker_line.width = line_width

        for label in self.number_labels:
            label.opacity = 0

        if marker_mode == "numbers":
            font_size = min(width, height) * (0.052 + marker_weight * 0.004) * variant_scale
            for hour, label in enumerate(self.number_labels, start=1):
                vector_x, vector_y = clock_vector_for_degrees(hour * 30)
                label.color = marker_color
                label.font_size = font_size
                label.bold = self.settings.get("markerVariant") in ("bold", "classic")
                label.size = (font_size * 1.8, font_size * 1.8)
                label.pos = (
                    cx + vector_x * radius - label.width / 2,
                    cy + vector_y * radius - label.height / 2,
                )
                label.opacity = 1

        self._update_time()

    def _set_video(self, path: Path | None) -> None:
        if path is None:
            self._video_ready = False
            if self.animated_face is not None:
                self.animated_face.anim_reset(False)
                self.animated_face.unbind(on_texture=self._update_video_texture)
                self.animated_face = None
            self._video_face.texture = None
            self._face_color.rgba = (0.05, 0.06, 0.08, 1)
            return

        self._video_ready = False
        self._video_face.texture = None
        self._face_color.rgba = (0.05, 0.06, 0.08, 1)
        if path.suffix.lower() in {".gif", ".zip"}:
            if self.animated_face is not None:
                self.animated_face.anim_reset(False)
                self.animated_face.unbind(on_texture=self._update_video_texture)
            try:
                self.animated_face = CoreImage(str(path), anim_delay=0.125, nocache=True)
                self.animated_face.bind(on_texture=self._update_video_texture)
                self._update_video_texture(self.animated_face)
                self.animated_face.anim_reset(True)
                print(f"Clock animation loaded: {path} ({self.animated_face.size})")
            except Exception as exc:
                self.animated_face = None
                print(f"Clock animation skipped: {path}: {exc}")
            return

        # MP4 playback through Kivy/GStreamer can freeze the UI on small Pi
        # models. New companion publishes use animated GIF; old MP4 packages
        # retain the native face rather than risking a black screen.
        return

    def _update_video_texture(self, source: CoreImage, *_args: Any) -> None:
        texture = source.texture
        if texture is None:
            return
        self._video_ready = True
        self._video_face.texture = texture
        self._face_color.rgba = (0.05, 0.06, 0.08, 0.08)

    def _update_time(self, *_args: Any) -> None:
        if self._radius <= 0:
            return

        cx, cy = self._center
        visible = bool(self.settings.get("showHands", True))
        hand_color = hex_to_rgba(self.settings.get("handColor", "#ffffff"))
        self._hand_color.rgba = (*hand_color[:3], hand_color[3] if visible else 0)
        hand_width = max(2, int(self.settings.get("handThickness", 8)))
        style = {
            "classic": (1, 0.72, 0.38, 0.52, 0.72, 0.82, 2.8),
            "rounded": (1.08, 0.78, 0.42, 0.54, 0.74, 0.84, 3.0),
            "slim": (0.58, 0.42, 0.22, 0.56, 0.78, 0.86, 2.0),
            "bold": (1.48, 1.08, 0.48, 0.50, 0.70, 0.80, 3.5),
            "needle": (0.48, 0.34, 0.18, 0.60, 0.82, 0.88, 1.8),
        }.get(str(self.settings.get("handStyle")), (1, 0.72, 0.38, 0.52, 0.72, 0.82, 2.8))
        hour_width, minute_width, second_width, hour_length, minute_length, second_length, pin_scale = style
        self._hour_hand.width = max(1, hand_width * hour_width)
        self._minute_hand.width = max(1, hand_width * minute_width)
        self._second_hand.width = max(1, hand_width * second_width)
        dot_size = max(8, hand_width * pin_scale)
        self._center_dot.pos = (cx - dot_size / 2, cy - dot_size / 2)
        self._center_dot.size = (dot_size, dot_size)

        hour_degrees, minute_degrees, second_degrees = hand_degrees_for_time(clock_now())
        self._hour_hand.points = self._hand_points(cx, cy, self._radius * hour_length, hour_degrees)
        self._minute_hand.points = self._hand_points(cx, cy, self._radius * minute_length, minute_degrees)
        self._second_hand.points = self._hand_points(cx, cy, self._radius * second_length, second_degrees)

    @staticmethod
    def _hand_points(cx: float, cy: float, length: float, degrees: float) -> list[float]:
        vector_x, vector_y = clock_vector_for_degrees(degrees)
        return [cx, cy, cx + vector_x * length, cy + vector_y * length]


class DatePanel(FloatLayout):
    def __init__(self, **kwargs: Any) -> None:
        kwargs.setdefault("size_hint", (None, None))
        super().__init__(**kwargs)
        self.settings = dict(DEFAULT_SETTINGS)
        self.animated_background: CoreImage | None = None

        with self.canvas.before:
            self._panel_color = Color(0.02, 0.025, 0.04, 1)
            self._panel = Rectangle(pos=self.pos, size=self.size)
            self._shade_color = Color(0, 0, 0, 0.32)
            self._shade = Rectangle(pos=self.pos, size=self.size)

        self.day = Label(text="", bold=True, size_hint=(None, None))
        self.date = Label(text="", size_hint=(None, None))
        self.add_widget(self.day)
        self.add_widget(self.date)
        self.bind(pos=self._layout, size=self._layout)
        Clock.schedule_interval(self._update_text, 30)
        self._update_text()

    def set_design(self, design: ClockDesign) -> None:
        self.settings = {**DEFAULT_SETTINGS, **design.settings}
        font_name = register_design_font(design.font_file)
        self.day.font_name = font_name
        self.date.font_name = font_name
        self._set_video(design.date_video)
        self._layout()

    def set_default(self) -> None:
        self.settings = dict(DEFAULT_SETTINGS)
        self.day.font_name = "Roboto"
        self.date.font_name = "Roboto"
        self._set_video(None)
        self._layout()

    def _set_video(self, path: Path | None) -> None:
        if not path:
            if self.animated_background is not None:
                self.animated_background.anim_reset(False)
                self.animated_background.unbind(on_texture=self._update_background_texture)
                self.animated_background = None
            self._panel.texture = None
            self._panel_color.rgba = (0.02, 0.025, 0.04, 1)
            return

        self._panel.texture = None
        self._panel_color.rgba = (0.02, 0.025, 0.04, 1)
        if path.suffix.lower() not in {".gif", ".zip"}:
            return
        if self.animated_background is not None:
            self.animated_background.anim_reset(False)
            self.animated_background.unbind(on_texture=self._update_background_texture)
        try:
            self.animated_background = CoreImage(str(path), anim_delay=0.125, nocache=True)
            self.animated_background.bind(on_texture=self._update_background_texture)
            self._update_background_texture(self.animated_background)
            self.animated_background.anim_reset(True)
            print(f"Date animation loaded: {path} ({self.animated_background.size})")
        except Exception as exc:
            self.animated_background = None
            print(f"Date animation skipped: {path}: {exc}")

    def _update_background_texture(self, source: CoreImage, *_args: Any) -> None:
        texture = source.texture
        if texture is None:
            return
        self._panel.texture = texture
        self._panel_color.rgba = (1, 1, 1, 1)

    def _layout(self, *_args: Any) -> None:
        self._panel.pos = self.pos
        self._panel.size = self.size
        self._shade.pos = self.pos
        self._shade.size = self.size
        color = hex_to_rgba(self.settings.get("dateColor", "#ffffff"))
        weight = max(1, int(self.settings.get("dateWeight", 6)))
        day_size = min(self.height * 0.34, 40 + weight * 4)
        date_size = min(self.height * 0.22, 24 + weight * 2)

        self.day.color = color
        self.day.bold = self.settings.get("dateVariant") in ("bold", "classic")
        self.day.font_size = day_size
        self.day.pos = (self.x, self.y + self.height * 0.42)
        self.day.size = (self.width, self.height * 0.38)

        self.date.color = (*color[:3], 0.9)
        self.date.font_size = date_size
        self.date.pos = (self.x, self.y + self.height * 0.14)
        self.date.size = (self.width, self.height * 0.28)

    def _update_text(self, *_args: Any) -> None:
        now = clock_now()
        self.day.text = now.strftime("%A").upper()
        self.date.text = f"{now.strftime('%B')} {now.day}, {now.year}"


class ClockDisplay(FloatLayout):
    def __init__(self, **kwargs: Any) -> None:
        kwargs.setdefault("size_hint", (None, None))
        super().__init__(**kwargs)
        self.design: ClockDesign | None = None
        self.safe_scale = self._read_safe_scale()

        with self.canvas.before:
            self._background_color = Color(0, 0, 0, 1)
            self._background = Rectangle(pos=self.pos, size=self.size)

        self.clock_face = ClockFace()
        self.date_panel = DatePanel()
        self.message = Label(
            text="",
            font_size=26,
            color=(1, 1, 1, 0.75),
            size_hint=(None, None),
            opacity=0,
        )
        self.add_widget(self.clock_face)
        self.add_widget(self.date_panel)
        self.add_widget(self.message)
        self.bind(pos=self._layout, size=self._layout)

    @staticmethod
    def _read_safe_scale() -> float:
        try:
            return min(1.0, max(0.5, float(os.environ.get("CLOCK_PLAYER_SAFE_SCALE", "1.0"))))
        except ValueError:
            return 1.0

    def set_design(self, design: ClockDesign | None) -> None:
        self.design = design
        self.message.opacity = 0
        self.clock_face.opacity = 1
        if design is None:
            self.clock_face.set_default()
            self.date_panel.set_default()
        else:
            self.clock_face.set_design(design)
            self.date_panel.set_design(design)
        self._layout()

    def _layout(self, *_args: Any) -> None:
        self._background.pos = self.pos
        self._background.size = self.size

        safe_width = self.width * self.safe_scale
        safe_height = self.height * self.safe_scale
        safe_x = self.x + (self.width - safe_width) / 2
        safe_y = self.y + (self.height - safe_height) / 2

        is_portrait = safe_height > safe_width * 1.1
        if is_portrait:
            side = min(safe_width * 0.94, safe_height * 0.56)
            date_w = min(safe_width * 0.88, side * 0.94)
            date_h = max(92, min(side * 0.18, safe_height * 0.12))
            clock_center_y = safe_y + safe_height * 0.63
            date_center_y = safe_y + safe_height * 0.23
            clock_y = clock_center_y - side / 2
            date_y = date_center_y - date_h / 2
            clock_x = safe_x + safe_width / 2 - side / 2
            date_x = safe_x + safe_width / 2 - date_w / 2
        else:
            side = min(safe_width * 0.78, safe_height * 0.72)
            clock_x = safe_x + safe_width / 2 - side / 2
            clock_y = safe_y + safe_height * 0.24
            date_w = side * 0.78
            date_h = max(64, min(safe_height * 0.15, 112))
            date_x = safe_x + safe_width / 2 - date_w / 2
            date_y = safe_y + safe_height * 0.055

        self.clock_face.pos = (clock_x, clock_y)
        self.clock_face.size = (side, side)
        self.date_panel.pos = (date_x, date_y)
        self.date_panel.size = (date_w, date_h)
        self.message.pos = self.pos
        self.message.size = self.size
