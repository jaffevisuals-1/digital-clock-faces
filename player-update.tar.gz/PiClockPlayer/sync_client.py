from __future__ import annotations

import hashlib
import json
import socket
import shutil
import tempfile
import time
from pathlib import Path
from urllib.parse import urljoin
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from playlist_loader import Playlist, load_playlist, playlist_is_newer


def load_config(config_path: Path) -> dict:
    if not config_path.exists():
        return {"sync": {"enabled": False}}
    return json.loads(config_path.read_text(encoding="utf-8"))


def sync_if_newer(config: dict, library_dir: Path, current: Playlist) -> bool:
    sync = config.get("sync") or {}
    if not sync.get("enabled"):
        return False

    source = str(sync.get("source") or "").strip()
    if not source:
        return False

    heartbeat_enabled = bool(sync.get("heartbeatEnabled", True))
    _send_heartbeat(source, current.version, "checking", heartbeat_enabled)

    with tempfile.TemporaryDirectory(prefix="clock-sync-") as temp_name:
        temp_dir = Path(temp_name)
        if source.startswith(("http://", "https://")):
            _download_http_package(source, temp_dir)
        else:
            _copy_local_package(Path(source).expanduser(), temp_dir)

        manifest = json.loads((temp_dir / "playlist.json").read_text(encoding="utf-8"))
        _validate_package(temp_dir, manifest)

        candidate = load_playlist(temp_dir)
        if not candidate.designs or not playlist_is_newer(candidate, current):
            _send_heartbeat(source, current.version, "up-to-date", heartbeat_enabled)
            return False

        _replace_library(temp_dir, library_dir)
        _send_heartbeat(source, candidate.version, "applied", heartbeat_enabled)
        return True


def _copy_local_package(source: Path, destination: Path) -> None:
    if not source.exists():
        raise FileNotFoundError(source)
    shutil.copytree(source, destination, dirs_exist_ok=True)


def _download_http_package(source: str, destination: Path) -> None:
    destination.mkdir(parents=True, exist_ok=True)
    playlist_url = urljoin(source.rstrip("/") + "/", "playlist.json")
    playlist = _download_bytes(f"{playlist_url}?clock={time.time_ns()}")
    (destination / "playlist.json").write_bytes(playlist)
    data = json.loads(playlist.decode("utf-8"))

    for media_path in _referenced_paths(data):
        relative = _safe_package_path(media_path)
        target = destination / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(_download_bytes(urljoin(source.rstrip("/") + "/", relative.as_posix())))


def _download_bytes(url: str) -> bytes:
    last_error: Exception | None = None
    for attempt in range(3):
        request = Request(
            url,
            headers={
                "User-Agent": "DigitalClockPlayer/1.0",
                "Cache-Control": "no-cache",
                "Pragma": "no-cache",
                "ngrok-skip-browser-warning": "clock-player",
            },
        )
        try:
            with urlopen(request, timeout=30) as response:
                return response.read()
        except HTTPError as exc:
            last_error = exc
            if exc.code < 500 and exc.code != 429:
                raise
        except (URLError, TimeoutError, ConnectionError, OSError) as exc:
            last_error = exc
        if attempt < 2:
            time.sleep(1.5 * (attempt + 1))
    assert last_error is not None
    raise last_error


def _send_heartbeat(source: str, installed_version: int, status: str, enabled: bool = True) -> None:
    if not enabled or not source.startswith(("http://", "https://")):
        return
    url = urljoin(source.rstrip("/") + "/", "heartbeat")
    body = json.dumps(
        {
            "hostname": socket.gethostname(),
            "installedVersion": installed_version,
            "status": status,
        }
    ).encode("utf-8")
    request = Request(
        url,
        data=body,
        headers={
            "Content-Type": "application/json",
            "User-Agent": "DigitalClockPlayer/1.0",
            "ngrok-skip-browser-warning": "clock-player",
        },
        method="POST",
    )
    try:
        with urlopen(request, timeout=4):
            pass
    except OSError:
        pass


def _referenced_paths(manifest: dict) -> set[str]:
    paths: set[str] = set()
    for design in manifest.get("designs", []):
        for key in ("clockVideo", "dateVideo", "fontFile"):
            value = design.get(key)
            if value:
                paths.add(str(value))
    return paths


def _safe_package_path(value: str) -> Path:
    path = Path(value)
    if path.is_absolute() or not path.parts or ".." in path.parts:
        raise ValueError(f"Invalid package path: {value}")
    return path


def _validate_package(root: Path, manifest: dict) -> None:
    schema_version = int(manifest.get("schemaVersion", 1) or 1)
    assets = manifest.get("assets") or {}
    for value in _referenced_paths(manifest):
        relative = _safe_package_path(value)
        candidate = root / relative
        if not candidate.is_file():
            raise ValueError(f"Package asset is missing: {relative.as_posix()}")
        if schema_version < 2:
            continue
        record = assets.get(relative.as_posix())
        if not isinstance(record, dict):
            raise ValueError(f"Schema 2 asset metadata is missing: {relative.as_posix()}")
        expected_size = int(record.get("bytes", -1))
        if candidate.stat().st_size != expected_size:
            raise ValueError(f"Package asset size mismatch: {relative.as_posix()}")
        expected_hash = str(record.get("sha256") or "").lower()
        actual_hash = hashlib.sha256(candidate.read_bytes()).hexdigest()
        if len(expected_hash) != 64 or actual_hash != expected_hash:
            raise ValueError(f"Package asset checksum mismatch: {relative.as_posix()}")


def _replace_library(source: Path, library_dir: Path) -> None:
    backup_dir = library_dir.with_name(f"{library_dir.name}.previous")
    next_dir = library_dir.with_name(f"{library_dir.name}.next")
    library_dir.parent.mkdir(parents=True, exist_ok=True)
    if next_dir.exists():
        shutil.rmtree(next_dir)
    shutil.copytree(source, next_dir)
    if backup_dir.exists():
        shutil.rmtree(backup_dir)
    if library_dir.exists():
        library_dir.rename(backup_dir)
    try:
        next_dir.rename(library_dir)
    except Exception:
        if backup_dir.exists() and not library_dir.exists():
            backup_dir.rename(library_dir)
        raise
