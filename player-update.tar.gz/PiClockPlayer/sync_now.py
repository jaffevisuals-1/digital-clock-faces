from __future__ import annotations

import os
from pathlib import Path

from playlist_loader import DEFAULT_LIBRARY_DIR, load_playlist
from sync_client import load_config, sync_if_newer


def main() -> int:
    config_path = Path(
        os.environ.get(
            "CLOCK_PLAYER_CONFIG",
            Path.home() / ".config" / "clock-player" / "config.json",
        )
    ).expanduser()
    config = load_config(config_path)
    library_dir = Path(config.get("libraryDir") or DEFAULT_LIBRARY_DIR).expanduser()
    current = load_playlist(library_dir)
    changed = sync_if_newer(config, library_dir, current)
    latest = load_playlist(library_dir)
    state = "downloaded" if changed else "already current"
    print(
        f"Clock playlist {state}: version {latest.version}, "
        f"{len(latest.designs)} design(s)."
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
