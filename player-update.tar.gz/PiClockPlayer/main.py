from __future__ import annotations

import random
import os
import signal
import threading
from pathlib import Path

from kivy.config import Config

WINDOWED = os.environ.get("CLOCK_PLAYER_WINDOWED") == "1"
WINDOW_MODE = os.environ.get("CLOCK_PLAYER_WINDOW_MODE") == "1"
ORIENTATION = os.environ.get("CLOCK_PLAYER_ORIENTATION", "portrait").lower()
PORTRAIT = ORIENTATION == "portrait"
APP_ROTATION = os.environ.get("CLOCK_PLAYER_ROTATION", "90")
DISPLAY_WIDTH = os.environ.get("CLOCK_PLAYER_WIDTH", "1080" if PORTRAIT else "1024")
DISPLAY_HEIGHT = os.environ.get("CLOCK_PLAYER_HEIGHT", "1920" if PORTRAIT else "600")
Config.set("graphics", "maxfps", "30")

if WINDOWED:
    Config.set("graphics", "fullscreen", "0")
    Config.set("graphics", "borderless", "0")
    Config.set("graphics", "width", "520" if PORTRAIT else "900")
    Config.set("graphics", "height", "924" if PORTRAIT else "520")
    Config.set("graphics", "show_cursor", "1")
elif WINDOW_MODE:
    Config.set("graphics", "fullscreen", "0")
    Config.set("graphics", "borderless", "1")
    Config.set("graphics", "width", DISPLAY_WIDTH)
    Config.set("graphics", "height", DISPLAY_HEIGHT)
    Config.set("graphics", "position", "custom")
    Config.set("graphics", "left", "0")
    Config.set("graphics", "top", "0")
    Config.set("graphics", "show_cursor", "0")
else:
    Config.set("graphics", "fullscreen", "auto")
    Config.set("graphics", "borderless", "1")
    Config.set("graphics", "show_cursor", "0")

from kivy.app import App
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.graphics import Color, PopMatrix, PushMatrix, Rectangle, Rotate, Scale, Translate
from kivy.uix.button import Button
from kivy.uix.floatlayout import FloatLayout

from clock_renderer import ClockDisplay
from playlist_loader import (
    DEFAULT_LIBRARY_DIR,
    Playlist,
    load_playlist,
    playlist_is_newer,
    preferred_design_index,
)
from playlist_controls import shifted_index
from sync_client import load_config, sync_if_newer


DESIGN_WIDTH = 1080
DESIGN_HEIGHT = 1920


class PlayerRoot(FloatLayout):
    def __init__(
        self,
        display: ClockDisplay,
        orientation: str,
        rotation: str,
        on_previous,
        on_next,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.display = display
        self.display.size_hint = (None, None)
        self.orientation = orientation
        self.rotation = self._normalize_rotation(rotation)
        self._last_layout_key: tuple[float, float, float, float, float, int] | None = None
        self.stage = FloatLayout(size_hint=(None, None), pos=(0, 0), size=(DESIGN_WIDTH, DESIGN_HEIGHT))
        self.display.pos = (0, 0)
        self.display.size = (DESIGN_WIDTH, DESIGN_HEIGHT)
        self.stage.add_widget(self.display)
        self.previous_button = self._control_button("<", (64, 52), on_previous)
        self.next_button = self._control_button(">", (896, 52), on_next)
        self.stage.add_widget(self.previous_button)
        self.stage.add_widget(self.next_button)
        self.add_widget(self.stage)
        with self.canvas.before:
            self._background_color = Color(0, 0, 0, 1)
            self._background = Rectangle(pos=self.pos, size=self.size)
        with self.stage.canvas.before:
            self._push = PushMatrix()
            self._translate_to_screen = Translate(0, 0, 0)
            self._scale_to_screen = Scale(1, 1, 1)
            self._translate_for_rotation = Translate(0, 0, 0)
            self._rotate_to_screen = Rotate(angle=0, origin=(0, 0))
        with self.stage.canvas.after:
            self._pop = PopMatrix()
        self.bind(pos=self._schedule_layout, size=self._schedule_layout)
        Clock.schedule_once(lambda _dt: self._layout(), 0)

    @staticmethod
    def _control_button(text: str, pos: tuple[int, int], callback) -> Button:
        button = Button(
            text=text,
            font_size=54,
            bold=True,
            size_hint=(None, None),
            size=(120, 108),
            pos=pos,
            color=(1, 1, 1, 0.52),
            background_normal="",
            background_down="",
            background_color=(1, 1, 1, 0.06),
        )
        button.bind(on_release=lambda *_args: callback())
        return button

    @staticmethod
    def _normalize_rotation(value: str) -> int:
        try:
            rotation = int(value)
        except (TypeError, ValueError):
            return 90
        return rotation if rotation in (0, 90, 270) else 90

    def _schedule_layout(self, *_args):
        Clock.unschedule(self._layout)
        Clock.schedule_once(self._layout, 0.05)

    def _layout(self, *_args):
        if self.width <= 0 or self.height <= 0:
            return

        self._background.pos = self.pos
        self._background.size = self.size
        should_rotate = (
            self.orientation == "portrait"
            and self.rotation in (90, 270)
            and self.width > self.height
        )

        source_width = DESIGN_HEIGHT if should_rotate else DESIGN_WIDTH
        source_height = DESIGN_WIDTH if should_rotate else DESIGN_HEIGHT
        scale = min(self.width / source_width, self.height / source_height)
        left = self.x + (self.width - source_width * scale) / 2
        bottom = self.y + (self.height - source_height * scale) / 2
        layout_key = (
            round(left, 3),
            round(bottom, 3),
            round(scale, 6),
            round(self.width, 3),
            round(self.height, 3),
            self.rotation if should_rotate else 0,
        )
        if layout_key == self._last_layout_key:
            return
        self._last_layout_key = layout_key

        self.stage.pos = (0, 0)
        self.stage.size = (DESIGN_WIDTH, DESIGN_HEIGHT)
        self.display.pos = (0, 0)
        self.display.size = (DESIGN_WIDTH, DESIGN_HEIGHT)
        self._translate_to_screen.x = left
        self._translate_to_screen.y = bottom
        self._scale_to_screen.x = scale
        self._scale_to_screen.y = scale
        self._scale_to_screen.z = 1

        if should_rotate:
            if self.rotation == 90:
                self._translate_for_rotation.x = DESIGN_HEIGHT
                self._translate_for_rotation.y = 0
                self._rotate_to_screen.angle = 90
            else:
                self._translate_for_rotation.x = 0
                self._translate_for_rotation.y = DESIGN_WIDTH
                self._rotate_to_screen.angle = -90
        else:
            self._translate_for_rotation.x = 0
            self._translate_for_rotation.y = 0
            self._rotate_to_screen.angle = 0


class ClockPlayerApp(App):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.config_path = Path(
            os.environ.get("CLOCK_PLAYER_CONFIG", Path.home() / ".config" / "clock-player" / "config.json")
        ).expanduser()
        self.config_data = load_config(self.config_path)
        self.library_dir = Path(
            self.config_data.get("libraryDir") or DEFAULT_LIBRARY_DIR
        ).expanduser()
        self.playlist = Playlist(version=0, updated_at="", designs=[])
        self.current_index = 0
        self.remaining_seconds = 0
        self.sync_in_progress = False
        self.display = ClockDisplay()
        self.root_widget = PlayerRoot(
            self.display,
            ORIENTATION,
            APP_ROTATION,
            self.previous_design,
            self.next_design,
        )

    def build(self):
        Window.bind(on_key_down=self._on_key_down)
        signal.signal(signal.SIGUSR1, self._signal_next)
        signal.signal(signal.SIGUSR2, self._signal_previous)
        self.load_initial_playlist()
        Clock.schedule_interval(self.tick, 1)
        interval = max(5, int(self.config_data.get("sync", {}).get("intervalSeconds", 15)))
        Clock.schedule_interval(self.check_for_updates, interval)
        Clock.schedule_once(self.check_for_updates, 2)
        return self.root_widget

    def load_initial_playlist(self) -> None:
        self.playlist = load_playlist(self.library_dir)
        if not self.playlist.designs:
            self.display.set_design(None)
            return
        self.current_index = random.randrange(len(self.playlist.designs))
        self.show_current_design()

    def show_current_design(self) -> None:
        if not self.playlist.designs:
            self.display.set_design(None)
            self.remaining_seconds = 30
            return
        design = self.playlist.designs[self.current_index]
        self.display.set_design(design)
        self.remaining_seconds = max(1, design.duration_minutes) * 60

    def tick(self, _dt: float) -> None:
        if not self.playlist.designs:
            return
        self.remaining_seconds -= 1
        if self.remaining_seconds <= 0:
            self.advance_design()

    def advance_design(self) -> None:
        self.move_design(1)

    def next_design(self) -> None:
        self.move_design(1)

    def previous_design(self) -> None:
        self.move_design(-1)

    def move_design(self, offset: int) -> None:
        if not self.playlist.designs:
            return
        latest = load_playlist(self.library_dir)
        if latest.designs and playlist_is_newer(latest, self.playlist):
            current_id = self.playlist.designs[self.current_index].id
            self.playlist = latest
            self.current_index = preferred_design_index(latest, current_id)
        self.current_index = shifted_index(
            self.current_index,
            len(self.playlist.designs),
            offset,
        )
        self.show_current_design()

    def _on_key_down(self, _window, key, _scancode, _codepoint, _modifiers) -> bool:
        if key == 276:
            self.previous_design()
            return True
        if key in (275, 32):
            self.next_design()
            return True
        return False

    def _signal_next(self, _signum, _frame) -> None:
        Clock.schedule_once(lambda _dt: self.next_design(), 0)

    def _signal_previous(self, _signum, _frame) -> None:
        Clock.schedule_once(lambda _dt: self.previous_design(), 0)

    def check_for_updates(self, _dt: float) -> None:
        if self.sync_in_progress:
            return
        self.sync_in_progress = True
        threading.Thread(target=self._sync_worker, name="clock-sync", daemon=True).start()

    def _sync_worker(self) -> None:
        changed = False
        error: Exception | None = None
        try:
            changed = sync_if_newer(self.config_data, self.library_dir, self.playlist)
        except Exception as exc:
            error = exc
        Clock.schedule_once(lambda _dt: self._finish_sync(changed, error), 0)

    def _finish_sync(self, changed: bool, error: Exception | None) -> None:
        self.sync_in_progress = False
        if error is not None:
            print(f"Sync skipped: {error}")
            return
        if not changed:
            return
        previous_design_id = ""
        if self.playlist.designs:
            previous_design_id = self.playlist.designs[self.current_index].id
        latest = load_playlist(self.library_dir)
        if not latest.designs:
            print("New clock release was empty; keeping the current display.")
            return
        self.playlist = latest
        self.current_index = preferred_design_index(latest, previous_design_id)
        self.show_current_design()
        print(f"Clock release {latest.version} activated immediately.")


if __name__ == "__main__":
    ClockPlayerApp().run()
