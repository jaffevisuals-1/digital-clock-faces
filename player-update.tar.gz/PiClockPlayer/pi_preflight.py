from __future__ import annotations

import importlib.util
import json
import os
import shutil
import sys
from pathlib import Path

from playlist_loader import DEFAULT_LIBRARY_DIR, load_playlist
from sync_client import load_config


def check(name: str, ok: bool, detail: str = "") -> bool:
    status = "OK" if ok else "FAIL"
    suffix = f" - {detail}" if detail else ""
    print(f"[{status}] {name}{suffix}")
    return ok


def main() -> int:
    failures = 0

    failures += not check(
        "Python version",
        sys.version_info >= (3, 9),
        ".".join(str(part) for part in sys.version_info[:3]),
    )

    failures += not check(
        "Kivy import",
        importlib.util.find_spec("kivy") is not None,
        "install python3-kivy on Raspberry Pi OS" if importlib.util.find_spec("kivy") is None else "",
    )

    failures += not check(
        "GStreamer tools",
        shutil.which("gst-launch-1.0") is not None,
        "install gstreamer1.0 tools/plugins" if shutil.which("gst-launch-1.0") is None else "",
    )

    failures += not check(
        "Display session",
        bool(os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY")),
        "run from the Pi desktop/autostart session",
    )

    config_path = Path.home() / ".config" / "clock-player" / "config.json"
    try:
        config = load_config(config_path)
        check("Config JSON", True, str(config_path))
    except json.JSONDecodeError as exc:
        failures += 1
        check("Config JSON", False, f"{config_path}: {exc}")
        config = {}

    library_dir = Path(config.get("libraryDir") or DEFAULT_LIBRARY_DIR).expanduser()
    failures += not check("Library folder", library_dir.exists(), str(library_dir))

    try:
        playlist = load_playlist(library_dir)
        failures += not check(
            "Playlist",
            bool(playlist.designs),
            f"{len(playlist.designs)} design(s) loaded from {library_dir / 'playlist.json'}",
        )
    except (OSError, json.JSONDecodeError) as exc:
        failures += 1
        check("Playlist", False, str(exc))
        playlist = None

    if playlist:
        missing_media = []
        playlist_path = library_dir / "playlist.json"
        playlist_data = json.loads(playlist_path.read_text(encoding="utf-8"))
        by_id = {str(design.id): design for design in playlist.designs}
        for raw_design in playlist_data.get("designs", []):
            design = by_id.get(str(raw_design.get("id")))
            if not design:
                continue
            if raw_design.get("clockVideo") and design.clock_video is None:
                missing_media.append(f"{design.name}: clockVideo")
            if raw_design.get("dateVideo") and design.date_video is None:
                missing_media.append(f"{design.name}: dateVideo")

        failures += not check(
            "Media files",
            not missing_media,
            "all referenced files found" if not missing_media else ", ".join(missing_media),
        )

    print()
    if failures:
        print(f"Preflight failed with {failures} issue(s).")
        return 1

    print("Preflight passed. The Pi environment is ready for a live playback test.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
