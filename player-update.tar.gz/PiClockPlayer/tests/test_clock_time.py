from __future__ import annotations

import unittest
from datetime import datetime, timezone
from zoneinfo import ZoneInfo

from clock_time import DEFAULT_TIMEZONE, clock_vector_for_degrees, hand_degrees_for_time


class ClockTimeTests(unittest.TestCase):
    def test_three_oclock(self) -> None:
        self.assertEqual(hand_degrees_for_time(datetime(2026, 1, 1, 3, 0, 0)), (90, 0, 0))

    def test_half_past_six(self) -> None:
        self.assertEqual(hand_degrees_for_time(datetime(2026, 1, 1, 6, 30, 0)), (195, 180, 0))

    def test_seconds_advance_all_hands(self) -> None:
        hour, minute, second = hand_degrees_for_time(datetime(2026, 1, 1, 12, 15, 30))
        self.assertAlmostEqual(hour, 7.75)
        self.assertAlmostEqual(minute, 93)
        self.assertAlmostEqual(second, 180)

    def test_new_york_winter_is_est(self) -> None:
        eastern = datetime(2026, 1, 15, 15, tzinfo=timezone.utc).astimezone(ZoneInfo(DEFAULT_TIMEZONE))
        self.assertEqual((eastern.hour, eastern.tzname()), (10, "EST"))

    def test_new_york_summer_is_edt(self) -> None:
        eastern = datetime(2026, 6, 28, 15, tzinfo=timezone.utc).astimezone(ZoneInfo(DEFAULT_TIMEZONE))
        self.assertEqual((eastern.hour, eastern.tzname()), (11, "EDT"))

    def test_clock_vectors_match_traditional_clock_positions(self) -> None:
        expected = {
            0: (0, 1),
            90: (1, 0),
            180: (0, -1),
            270: (-1, 0),
        }
        for degrees, (expected_x, expected_y) in expected.items():
            vector_x, vector_y = clock_vector_for_degrees(degrees)
            self.assertAlmostEqual(vector_x, expected_x)
            self.assertAlmostEqual(vector_y, expected_y)

    def test_seconds_move_clockwise_from_twelve(self) -> None:
        at_twelve = clock_vector_for_degrees(0)
        one_second_later = clock_vector_for_degrees(6)
        self.assertAlmostEqual(at_twelve[0], 0)
        self.assertGreater(one_second_later[0], at_twelve[0])
        self.assertLess(one_second_later[1], at_twelve[1])


if __name__ == "__main__":
    unittest.main()
