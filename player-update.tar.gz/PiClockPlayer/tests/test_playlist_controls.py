from __future__ import annotations

import unittest

from playlist_controls import shifted_index


class PlaylistControlTests(unittest.TestCase):
    def test_moves_forward(self) -> None:
        self.assertEqual(shifted_index(0, 3, 1), 1)

    def test_wraps_forward(self) -> None:
        self.assertEqual(shifted_index(2, 3, 1), 0)

    def test_wraps_backward(self) -> None:
        self.assertEqual(shifted_index(0, 3, -1), 2)

    def test_empty_playlist_stays_at_zero(self) -> None:
        self.assertEqual(shifted_index(4, 0, 1), 0)


if __name__ == "__main__":
    unittest.main()
