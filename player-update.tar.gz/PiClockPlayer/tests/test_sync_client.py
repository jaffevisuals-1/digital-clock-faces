from __future__ import annotations

import json
import hashlib
import tempfile
import unittest
from pathlib import Path

from playlist_loader import Playlist, load_playlist
from sync_client import sync_if_newer


class SyncClientTests(unittest.TestCase):
    def test_applies_media_font_and_settings_atomically(self) -> None:
        with tempfile.TemporaryDirectory() as temp_name:
            root = Path(temp_name)
            source = root / "source"
            library = root / "library"
            (source / "media").mkdir(parents=True)
            (source / "fonts").mkdir()
            (source / "media" / "face.mp4").write_bytes(b"video")
            (source / "fonts" / "type.ttf").write_bytes(b"font")
            manifest = {
                "version": 2,
                "updatedAt": "2026-06-28T12:00:00Z",
                "designOrder": ["one"],
                "designs": [
                    {
                        "id": "one",
                        "name": "Synced Face",
                        "durationMinutes": 30,
                        "clockVideo": "media/face.mp4",
                        "dateVideo": None,
                        "fontFile": "fonts/type.ttf",
                        "settings": {"handStyle": "needle"},
                    }
                ],
            }
            (source / "playlist.json").write_text(json.dumps(manifest), encoding="utf-8")

            config = {"sync": {"enabled": True, "source": str(source)}}
            current = Playlist(version=0, updated_at="", designs=[])
            self.assertTrue(sync_if_newer(config, library, current))

            synced = load_playlist(library)
            self.assertEqual(synced.version, 2)
            self.assertEqual(synced.designs[0].settings["handStyle"], "needle")
            self.assertEqual(synced.designs[0].clock_video.read_bytes(), b"video")
            self.assertEqual(synced.designs[0].font_file.read_bytes(), b"font")
            self.assertFalse(sync_if_newer(config, library, synced))

    def test_schema_two_validates_checksum_before_atomic_swap(self) -> None:
        with tempfile.TemporaryDirectory() as temp_name:
            root = Path(temp_name)
            source = root / "source"
            library = root / "library"
            asset_path = Path("releases/3/media/face.gif")
            data = b"good-face"
            (source / asset_path).parent.mkdir(parents=True)
            (source / asset_path).write_bytes(data)
            manifest = {
                "schemaVersion": 2,
                "version": 3,
                "updatedAt": "2026-07-02T12:00:00Z",
                "designOrder": ["one"],
                "designs": [{"id": "one", "clockVideo": asset_path.as_posix()}],
                "assets": {
                    asset_path.as_posix(): {
                        "bytes": len(data),
                        "sha256": hashlib.sha256(data).hexdigest(),
                    }
                },
            }
            (source / "playlist.json").write_text(json.dumps(manifest), encoding="utf-8")
            current = Playlist(version=0, updated_at="", designs=[])
            self.assertTrue(sync_if_newer({"sync": {"enabled": True, "source": str(source)}}, library, current))
            self.assertEqual((library / asset_path).read_bytes(), data)

    def test_checksum_failure_preserves_previous_library(self) -> None:
        with tempfile.TemporaryDirectory() as temp_name:
            root = Path(temp_name)
            source = root / "source"
            library = root / "library"
            source.mkdir()
            library.mkdir()
            (library / "sentinel.txt").write_text("working", encoding="utf-8")
            (source / "media").mkdir()
            (source / "media" / "face.gif").write_bytes(b"corrupt")
            manifest = {
                "schemaVersion": 2,
                "version": 4,
                "designOrder": ["one"],
                "designs": [{"id": "one", "clockVideo": "media/face.gif"}],
                "assets": {"media/face.gif": {"bytes": 7, "sha256": "0" * 64}},
            }
            (source / "playlist.json").write_text(json.dumps(manifest), encoding="utf-8")
            current = Playlist(version=3, updated_at="", designs=[])
            with self.assertRaisesRegex(ValueError, "checksum mismatch"):
                sync_if_newer({"sync": {"enabled": True, "source": str(source)}}, library, current)
            self.assertEqual((library / "sentinel.txt").read_text(encoding="utf-8"), "working")


if __name__ == "__main__":
    unittest.main()
