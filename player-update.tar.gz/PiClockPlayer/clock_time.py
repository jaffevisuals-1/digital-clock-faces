from __future__ import annotations

import os
import math
from datetime import datetime
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError


DEFAULT_TIMEZONE = "America/New_York"


def clock_timezone() -> ZoneInfo:
    name = os.environ.get("CLOCK_PLAYER_TIMEZONE", DEFAULT_TIMEZONE)
    try:
        return ZoneInfo(name)
    except ZoneInfoNotFoundError:
        return ZoneInfo(DEFAULT_TIMEZONE)


def clock_now() -> datetime:
    """Return wall-clock time in the configured display timezone."""
    return datetime.now(clock_timezone())


def hand_degrees_for_time(now: datetime) -> tuple[float, float, float]:
    seconds = now.second + now.microsecond / 1_000_000
    minutes = now.minute + seconds / 60
    hours = (now.hour % 12) + minutes / 60
    return hours * 30, minutes * 6, seconds * 6


def clock_vector_for_degrees(degrees: float) -> tuple[float, float]:
    """Return a Kivy x/y vector where 0 is up and angles move clockwise."""
    angle = math.radians(90 - degrees)
    return math.cos(angle), math.sin(angle)
