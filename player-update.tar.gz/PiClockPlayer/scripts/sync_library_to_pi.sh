#!/usr/bin/env bash
set -euo pipefail

if [ "$#" -ne 2 ]; then
  echo "Usage: $0 /path/to/exported-pi-folder epjaffe@Ethan-Pi.local"
  exit 1
fi

PACKAGE_DIR="$1"
PI_TARGET="$2"

if [ ! -f "$PACKAGE_DIR/playlist.json" ]; then
  echo "Missing playlist.json in $PACKAGE_DIR"
  exit 1
fi

rsync -av --delete "$PACKAGE_DIR/" "$PI_TARGET:~/clock-player/library/"
ssh "$PI_TARGET" "~/clock-player/app/scripts/restart_player.sh"

echo "Synced playlist package to $PI_TARGET."
