#!/usr/bin/env bash
set -euo pipefail

if ! pkill -USR1 -f "[c]lock-player/app/main.py"; then
  echo "Clock player is not running."
  exit 1
fi
