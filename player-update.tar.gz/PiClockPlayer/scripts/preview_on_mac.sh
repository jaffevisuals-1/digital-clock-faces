#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

export CLOCK_PLAYER_WINDOWED=1
export CLOCK_PLAYER_ORIENTATION="${CLOCK_PLAYER_ORIENTATION:-portrait}"
export CLOCK_PLAYER_CONFIG="$APP_DIR/config.mac-preview.json"

cd "$APP_DIR"
python3 main.py
