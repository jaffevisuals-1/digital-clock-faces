#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

stop_legacy_players() {
  pkill -f "PiClockPlayer/main.py" 2>/dev/null || true
  pkill -f "clock-player/app/main.py" 2>/dev/null || true
  pkill -f "[p]ython3 main.py" 2>/dev/null || true
}

if systemctl --user is-enabled clock-player.service >/dev/null 2>&1; then
  systemctl --user stop clock-player.service >/dev/null 2>&1 || true
  stop_legacy_players
  systemctl --user start clock-player.service
  echo "Clock player service restarted."
else
  stop_legacy_players
  nohup "$APP_DIR/scripts/start_player.sh" >/tmp/clock-player.log 2>&1 &
  echo "Clock player restarted. Log: /tmp/clock-player.log"
fi
