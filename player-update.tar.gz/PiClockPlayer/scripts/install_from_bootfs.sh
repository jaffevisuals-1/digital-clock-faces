#!/usr/bin/env bash
set -euo pipefail

BOOT_APP=""
for candidate in \
  "/boot/firmware/ClockTransfer/PiClockPlayer" \
  "/boot/ClockTransfer/PiClockPlayer"
do
  if [ -d "$candidate" ]; then
    BOOT_APP="$candidate"
    break
  fi
done

if [ -z "$BOOT_APP" ]; then
  echo "Could not find ClockTransfer/PiClockPlayer on the SD card boot partition."
  echo "Expected /boot/firmware/ClockTransfer/PiClockPlayer or /boot/ClockTransfer/PiClockPlayer."
  exit 1
fi

for required in main.py clock_time.py clock_renderer.py playlist_loader.py playlist_controls.py sync_client.py sync_now.py; do
  if [ ! -f "$BOOT_APP/$required" ]; then
    echo "SD card package is incomplete: missing $required"
    echo "Repair the ClockTransfer folder on the Mac before installing."
    exit 1
  fi
done

if [ -f "$BOOT_APP/SHA256SUMS" ] && command -v sha256sum >/dev/null 2>&1; then
  echo "Verifying SD card package..."
  (cd "$BOOT_APP" && sha256sum --check SHA256SUMS)
fi

APP_DIR="$HOME/clock-player/app"
LIBRARY_DIR="$HOME/clock-player/library"
CONFIG_DIR="$HOME/.config/clock-player"
AUTOSTART_DIR="$HOME/.config/autostart"
SERVICE_DIR="$HOME/.config/systemd/user"

mkdir -p "$APP_DIR" "$LIBRARY_DIR" "$CONFIG_DIR" "$AUTOSTART_DIR" "$SERVICE_DIR"

if command -v rsync >/dev/null 2>&1; then
  rsync -av --delete --exclude "library/" "$BOOT_APP/" "$APP_DIR/"
else
  find "$APP_DIR" -mindepth 1 -maxdepth 1 ! -name "library" -exec rm -rf {} +
  cp -a "$BOOT_APP/." "$APP_DIR/"
fi

chmod +x "$APP_DIR"/scripts/*.sh 2>/dev/null || true

if [ ! -f "$LIBRARY_DIR/playlist.json" ] && [ -f "$BOOT_APP/library/playlist.json" ]; then
  cp "$BOOT_APP/library/playlist.json" "$LIBRARY_DIR/playlist.json"
fi

if [ ! -f "$CONFIG_DIR/config.json" ] && [ -f "$APP_DIR/config.example.json" ]; then
  cp "$APP_DIR/config.example.json" "$CONFIG_DIR/config.json"
fi

CLOUD_URL_FILE="$(dirname "$BOOT_APP")/cloud-sync-url.txt"
SYNC_URL_FILE="$(dirname "$BOOT_APP")/companion-sync-url.txt"
if [ -f "$CLOUD_URL_FILE" ]; then
  SYNC_URL="$(head -n 1 "$CLOUD_URL_FILE" | tr -d '\r\n')"
  if [ -n "$SYNC_URL" ]; then
    CLOCK_PLAYER_NO_RESTART=1 "$APP_DIR/scripts/configure_cloud_sync.sh" "$SYNC_URL"
  fi
elif [ -f "$SYNC_URL_FILE" ]; then
  SYNC_URL="$(head -n 1 "$SYNC_URL_FILE" | tr -d '\r\n')"
  if [ -n "$SYNC_URL" ]; then
    CLOCK_PLAYER_NO_RESTART=1 "$APP_DIR/scripts/configure_companion_sync.sh" "$SYNC_URL"
  fi
fi

python3 -m py_compile \
  "$APP_DIR/main.py" \
  "$APP_DIR/clock_time.py" \
  "$APP_DIR/clock_renderer.py" \
  "$APP_DIR/playlist_loader.py" \
  "$APP_DIR/playlist_controls.py" \
  "$APP_DIR/sync_client.py" \
  "$APP_DIR/sync_now.py"

cat > "$CONFIG_DIR/portrait.env" <<EOF
export CLOCK_PLAYER_ORIENTATION=portrait
export CLOCK_PLAYER_ROTATION=90
export CLOCK_PLAYER_WIDTH=1080
export CLOCK_PLAYER_HEIGHT=1920
export CLOCK_PLAYER_TIMEZONE=America/New_York
EOF

if command -v timedatectl >/dev/null 2>&1; then
  sudo timedatectl set-timezone America/New_York || true
  sudo timedatectl set-ntp true || true
fi
if command -v loginctl >/dev/null 2>&1; then
  sudo loginctl enable-linger "$USER" || true
fi

sed "s#%h/clock-player/app#$APP_DIR#g" \
  "$APP_DIR/systemd/clock-player.service" > "$SERVICE_DIR/clock-player.service"

systemctl --user stop clock-player.service >/dev/null 2>&1 || true
pkill -f "PiClockPlayer/main.py" 2>/dev/null || true
pkill -f "clock-player/app/main.py" 2>/dev/null || true
pkill -f "[p]ython3 main.py" 2>/dev/null || true

echo "Checking for the latest published clock faces..."
if PYTHONPATH="$APP_DIR" python3 "$APP_DIR/sync_now.py"; then
  echo "Cloud clock faces are ready."
else
  echo "Cloud download was unavailable; the last working faces were preserved."
fi

cat > "$AUTOSTART_DIR/clock-player.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=Digital Clock Player
Exec=$APP_DIR/scripts/start_at_login.sh
Terminal=false
X-GNOME-Autostart-enabled=true
EOF

if systemctl --user daemon-reload >/dev/null 2>&1 &&
   systemctl --user enable clock-player.service >/dev/null 2>&1 &&
   systemctl --user restart clock-player.service >/dev/null 2>&1; then
  echo "Clock player startup service installed and started. Desktop login fallback is also enabled."
else
  echo "User service was not available; desktop autostart was installed as fallback."
  "$APP_DIR/scripts/restart_player.sh"
fi

echo "Clock player installed from SD card boot partition."
