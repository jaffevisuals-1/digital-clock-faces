#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SERVICE_DIR="$HOME/.config/systemd/user"
AUTOSTART_DIR="$HOME/.config/autostart"
mkdir -p "$SERVICE_DIR" "$AUTOSTART_DIR"

"$APP_DIR/scripts/set_display_portrait.sh" 90 || true

if command -v loginctl >/dev/null 2>&1; then
  sudo loginctl enable-linger "$USER" || true
fi

sed "s#%h/clock-player/app#$APP_DIR#g" \
  "$APP_DIR/systemd/clock-player.service" > "$SERVICE_DIR/clock-player.service"

systemctl --user daemon-reload
systemctl --user enable clock-player.service
systemctl --user restart clock-player.service

cat > "$AUTOSTART_DIR/clock-player.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=Digital Clock Player
Exec=$APP_DIR/scripts/start_at_login.sh
Terminal=false
X-GNOME-Autostart-enabled=true
EOF

echo "User service installed and started. Desktop login fallback is also enabled."
