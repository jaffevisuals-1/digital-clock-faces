#!/usr/bin/env bash
set -euo pipefail

ROTATION="${1:-90}"
APPLY_ONLY="${2:-}"

if [ "$ROTATION" = "90" ]; then
  XRANDR_ROTATION="right"
elif [ "$ROTATION" = "270" ]; then
  XRANDR_ROTATION="left"
else
  echo "Usage: $0 [90|270]"
  exit 1
fi

WLR_OUTPUT="${CLOCK_PLAYER_OUTPUT:-}"
XRANDR_OUTPUT="${CLOCK_PLAYER_OUTPUT:-}"
APPLIED=0

if command -v wlr-randr >/dev/null 2>&1; then
  export XDG_RUNTIME_DIR="${XDG_RUNTIME_DIR:-/run/user/$(id -u)}"
  for WAYLAND_SOCKET in "${WAYLAND_DISPLAY:-}" wayland-1 wayland-0; do
    [ -n "$WAYLAND_SOCKET" ] || continue
    if [ -z "$WLR_OUTPUT" ]; then
      WLR_OUTPUT="$(WAYLAND_DISPLAY="$WAYLAND_SOCKET" wlr-randr 2>/dev/null | awk '/^[^ ]/ { print $1; exit }')"
    fi
    if [ -n "$WLR_OUTPUT" ] && WAYLAND_DISPLAY="$WAYLAND_SOCKET" wlr-randr --output "$WLR_OUTPUT" --transform "$ROTATION" >/dev/null 2>&1; then
      APPLIED=1
      break
    fi
  done
fi

if [ "$APPLIED" -eq 0 ] && command -v xrandr >/dev/null 2>&1; then
  if [ -z "$XRANDR_OUTPUT" ]; then
    XRANDR_OUTPUT="$(DISPLAY="${DISPLAY:-:0}" xrandr --query 2>/dev/null | awk '/ connected/ { print $1; exit }')"
  fi
  if [ -n "$XRANDR_OUTPUT" ] && DISPLAY="${DISPLAY:-:0}" xrandr --output "$XRANDR_OUTPUT" --rotate "$XRANDR_ROTATION" >/dev/null 2>&1; then
    APPLIED=1
  fi
fi

if [ "$APPLY_ONLY" != "--apply-only" ]; then
  CONFIG_DIR="$HOME/.config/clock-player"
  mkdir -p "$CONFIG_DIR"
  cat > "$CONFIG_DIR/portrait.env" <<EOF
export CLOCK_PLAYER_ORIENTATION=portrait
export CLOCK_PLAYER_ROTATION=$ROTATION
export CLOCK_PLAYER_WIDTH=1080
export CLOCK_PLAYER_HEIGHT=1920
export CLOCK_PLAYER_TIMEZONE=America/New_York
EOF
fi

if [ "$APPLIED" -eq 1 ]; then
  echo "Display rotation applied at $ROTATION degrees."
else
  echo "OS rotation unavailable; the app will use its $ROTATION-degree portrait fallback."
fi
