#!/usr/bin/env bash
set -euo pipefail

SOURCE="${1:-}"
if [ -z "$SOURCE" ]; then
  echo "Usage: $0 https://YOUR-CLOCK-FEED/sync/TOKEN/"
  exit 1
fi
SOURCE="${SOURCE%/}/"

TEMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TEMP_DIR"' EXIT
ARCHIVE="$TEMP_DIR/player-update.tar.gz"

python3 - "${SOURCE}player-update.tar.gz" "$ARCHIVE" <<'PY'
import shutil
import sys
import time
from urllib.request import Request, urlopen

url, destination = sys.argv[1:]
last_error = None
for attempt in range(20):
    try:
        request = Request(url, headers={
            "User-Agent": "DigitalClockPlayer/1.0",
            "ngrok-skip-browser-warning": "clock-player",
        })
        with urlopen(request, timeout=120) as response, open(destination, "wb") as output:
            shutil.copyfileobj(response, output)
        break
    except OSError as error:
        last_error = error
        if attempt == 19:
            raise
        time.sleep(2)
else:
    raise last_error
PY
tar -xzf "$ARCHIVE" -C "$TEMP_DIR"

APP_DIR="$HOME/clock-player/app"
mkdir -p "$APP_DIR"
if command -v rsync >/dev/null 2>&1; then
  rsync -av --delete --exclude 'library/' "$TEMP_DIR/PiClockPlayer/" "$APP_DIR/"
else
  cp -a "$TEMP_DIR/PiClockPlayer/." "$APP_DIR/"
fi
chmod +x "$APP_DIR"/scripts/*.sh
python3 -m py_compile \
  "$APP_DIR/main.py" \
  "$APP_DIR/clock_time.py" \
  "$APP_DIR/clock_renderer.py" \
  "$APP_DIR/playlist_loader.py" \
  "$APP_DIR/playlist_controls.py" \
  "$APP_DIR/sync_client.py" \
  "$APP_DIR/sync_now.py"

case "$SOURCE" in
  *raw.githubusercontent.com*)
    CLOCK_PLAYER_NO_RESTART=1 "$APP_DIR/scripts/configure_cloud_sync.sh" "$SOURCE"
    ;;
  *)
    CLOCK_PLAYER_NO_RESTART=1 "$APP_DIR/scripts/configure_companion_sync.sh" "$SOURCE"
    ;;
esac

# Refresh before Kivy starts. This also recovers a player that is stuck
# opening an older incompatible animation.
PYTHONPATH="$APP_DIR" python3 "$APP_DIR/sync_now.py"

"$APP_DIR/scripts/restart_player.sh"
echo "Clock player updated from the companion."
