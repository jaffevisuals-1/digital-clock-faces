#!/usr/bin/env bash
set -euo pipefail

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TARGET_ROOT="${CLOCK_PLAYER_ROOT:-$HOME/clock-player}"
TARGET_APP="$TARGET_ROOT/app"
TARGET_LIBRARY="$TARGET_ROOT/library"
CONFIG_DIR="$HOME/.config/clock-player"
AUTOSTART_DIR="$HOME/.config/autostart"
SERVICE_DIR="$HOME/.config/systemd/user"

echo "Installing system packages..."
sudo apt update
sudo apt install -y \
  python3-kivy \
  rsync \
  gstreamer1.0-tools \
  gstreamer1.0-plugins-base \
  gstreamer1.0-plugins-good \
  gstreamer1.0-plugins-bad \
  gstreamer1.0-plugins-ugly

echo "Copying player app to $TARGET_APP..."
mkdir -p "$TARGET_APP" "$TARGET_LIBRARY" "$CONFIG_DIR" "$AUTOSTART_DIR" "$SERVICE_DIR"
rsync -av --delete \
  --exclude "library" \
  "$SOURCE_DIR/" "$TARGET_APP/"

if [ ! -f "$TARGET_LIBRARY/playlist.json" ]; then
  cp "$SOURCE_DIR/library/playlist.json" "$TARGET_LIBRARY/playlist.json"
fi

if [ ! -f "$CONFIG_DIR/config.json" ]; then
  sed "s#/home/epjaffe/clock-player/library#$TARGET_LIBRARY#g" \
    "$SOURCE_DIR/config.example.json" > "$CONFIG_DIR/config.json"
fi

chmod +x "$TARGET_APP/scripts/"*.sh

cat > "$CONFIG_DIR/portrait.env" <<EOF
export CLOCK_PLAYER_ORIENTATION=portrait
export CLOCK_PLAYER_ROTATION=90
export CLOCK_PLAYER_WIDTH=1080
export CLOCK_PLAYER_HEIGHT=1920
export CLOCK_PLAYER_TIMEZONE=America/New_York
EOF

if command -v timedatectl >/dev/null 2>&1; then
  sudo timedatectl set-timezone America/New_York || true
  sudo timedatectl set-ntp true || true
fi

sed "s#%h/clock-player/app#$TARGET_APP#g" \
  "$TARGET_APP/systemd/clock-player.service" > "$SERVICE_DIR/clock-player.service"

systemctl --user stop clock-player.service >/dev/null 2>&1 || true
pkill -f "PiClockPlayer/main.py" 2>/dev/null || true
pkill -f "clock-player/app/main.py" 2>/dev/null || true
pkill -f "[p]ython3 main.py" 2>/dev/null || true

cat > "$AUTOSTART_DIR/clock-player.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=Digital Clock Player
Exec=$TARGET_APP/scripts/start_at_login.sh
Terminal=false
X-GNOME-Autostart-enabled=true
EOF

if systemctl --user daemon-reload >/dev/null 2>&1 &&
   systemctl --user enable clock-player.service >/dev/null 2>&1 &&
   systemctl --user restart clock-player.service >/dev/null 2>&1; then
  echo "Startup service installed and started. Desktop login fallback is also enabled."
else
  echo "User service was not available; desktop autostart was installed as fallback."
fi

echo "Installed. Reboot the Pi to auto-start, or run:"
echo "$TARGET_APP/scripts/start_player.sh"
