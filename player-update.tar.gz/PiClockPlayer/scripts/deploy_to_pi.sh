#!/usr/bin/env bash
set -euo pipefail

if [ "$#" -ne 1 ]; then
  echo "Usage: $0 epjaffe@Ethan-Pi.local"
  exit 1
fi

PI_TARGET="$1"
SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
REMOTE_DIR="~/PiClockPlayer"

rsync -av --delete "$SOURCE_DIR/" "$PI_TARGET:$REMOTE_DIR/"
ssh "$PI_TARGET" "cd $REMOTE_DIR && bash scripts/setup_pi.sh"

echo "Player deployed to $PI_TARGET."
