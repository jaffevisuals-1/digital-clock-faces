#!/usr/bin/env bash
set -euo pipefail

SOURCE="${1:-}"
if [ -z "$SOURCE" ]; then
  echo "Usage: $0 https://raw.githubusercontent.com/USER/REPOSITORY/main/"
  exit 1
fi

CONFIG_DIR="$HOME/.config/clock-player"
CONFIG_PATH="$CONFIG_DIR/config.json"
LIBRARY_DIR="$HOME/clock-player/library"
mkdir -p "$CONFIG_DIR"

python3 - "$CONFIG_PATH" "$LIBRARY_DIR" "$SOURCE" <<'PY'
import json
import sys
from pathlib import Path

path = Path(sys.argv[1])
config = {}
if path.exists():
    try:
        config = json.loads(path.read_text(encoding="utf-8"))
    except ValueError:
        config = {}
config["libraryDir"] = sys.argv[2]
config["sync"] = {
    "enabled": True,
    "source": sys.argv[3].rstrip("/") + "/",
    "intervalSeconds": 15,
    "heartbeatEnabled": False,
    "transport": "public-http",
}
path.write_text(json.dumps(config, indent=2), encoding="utf-8")
print(f"Cloud clock sync configured for {config['sync']['source']}")
PY

if [ "${CLOCK_PLAYER_NO_RESTART:-0}" != "1" ]; then
  "$HOME/clock-player/app/scripts/restart_player.sh"
fi
