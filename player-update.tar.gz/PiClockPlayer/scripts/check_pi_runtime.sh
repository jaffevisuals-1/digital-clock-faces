#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export KIVY_NO_ARGS=1

cd "$APP_DIR"
python3 pi_preflight.py
