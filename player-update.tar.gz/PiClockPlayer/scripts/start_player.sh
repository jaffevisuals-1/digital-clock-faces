#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
RUNTIME_DIR="${XDG_RUNTIME_DIR:-/run/user/$(id -u)}"
mkdir -p "$RUNTIME_DIR" 2>/dev/null || RUNTIME_DIR="/tmp"
LOCK_FILE="$RUNTIME_DIR/clock-player.lock"
exec 9>"$LOCK_FILE"
if ! flock -n 9; then
  echo "Clock player is already running."
  exit 0
fi

if [ -f "$HOME/.config/clock-player/portrait.env" ]; then
  # shellcheck disable=SC1090
  . "$HOME/.config/clock-player/portrait.env"
fi
export DISPLAY="${DISPLAY:-:0}"
export KIVY_NO_ARGS=1
export CLOCK_PLAYER_ORIENTATION="${CLOCK_PLAYER_ORIENTATION:-portrait}"
export CLOCK_PLAYER_ROTATION="${CLOCK_PLAYER_ROTATION:-90}"
export CLOCK_PLAYER_TIMEZONE="${CLOCK_PLAYER_TIMEZONE:-America/New_York}"
export TZ="$CLOCK_PLAYER_TIMEZONE"
if [ "$CLOCK_PLAYER_ORIENTATION" = "portrait" ]; then
  export CLOCK_PLAYER_WIDTH="${CLOCK_PLAYER_WIDTH:-1080}"
  export CLOCK_PLAYER_HEIGHT="${CLOCK_PLAYER_HEIGHT:-1920}"
else
  export CLOCK_PLAYER_WIDTH="${CLOCK_PLAYER_WIDTH:-1024}"
  export CLOCK_PLAYER_HEIGHT="${CLOCK_PLAYER_HEIGHT:-600}"
fi
export CLOCK_PLAYER_SAFE_SCALE="${CLOCK_PLAYER_SAFE_SCALE:-1.0}"

# Apply the physical display rotation on each graphical-session start. If the
# compositor is unavailable, main.py still rotates its fixed portrait canvas.
"$APP_DIR/scripts/set_display_portrait.sh" "$CLOCK_PLAYER_ROTATION" --apply-only || true

cd "$APP_DIR"
exec python3 "$APP_DIR/main.py"
