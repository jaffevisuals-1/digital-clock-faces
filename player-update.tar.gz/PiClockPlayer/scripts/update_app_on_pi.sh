#!/usr/bin/env bash
set -euo pipefail

if [ "$#" -ne 1 ]; then
  echo "Usage: $0 epjaffe@Ethan-Pi.local"
  exit 1
fi

PI_TARGET="$1"
SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

rsync -av --delete \
  --exclude "library/" \
  "$SOURCE_DIR/" "$PI_TARGET:~/clock-player/app/"

ssh "$PI_TARGET" "~/clock-player/app/scripts/restart_player.sh"

echo "Player app updated on $PI_TARGET."
