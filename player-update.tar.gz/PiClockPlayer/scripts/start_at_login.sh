#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

# A user service may begin before the desktop is fully available. Refresh its
# graphical-session variables at login, then restart the same service once.
if command -v systemctl >/dev/null 2>&1 &&
   systemctl --user cat clock-player.service >/dev/null 2>&1; then
  systemctl --user import-environment \
    DISPLAY WAYLAND_DISPLAY XDG_RUNTIME_DIR DBUS_SESSION_BUS_ADDRESS 2>/dev/null || true
  systemctl --user restart clock-player.service
else
  "$APP_DIR/scripts/start_player.sh"
fi
