#!/usr/bin/env bash
set -euo pipefail

SOURCE="${1:-}"
if [ -z "$SOURCE" ]; then
  echo "Usage: $0 https://raw.githubusercontent.com/USER/REPOSITORY/main/"
  exit 1
fi
SOURCE="${SOURCE%/}/"

python3 - "${SOURCE}connectivity-check.txt" <<'PY'
import sys
from urllib.request import Request, urlopen

request = Request(sys.argv[1], headers={"User-Agent": "DigitalClockPlayer/1.0"})
with urlopen(request, timeout=30) as response:
    body = response.read().decode("utf-8")
if not body.startswith(("digital-clock-cloud-ok ", "digital-clock-r2-ok ")):
    raise SystemExit("Cloud host returned an unexpected connectivity response")
print("Public cloud connectivity check passed.")
PY

"$HOME/clock-player/app/scripts/configure_cloud_sync.sh" "$SOURCE"
