(() => {
  "use strict";

  const TIME_ZONE = "America/New_York";
  const CENTER = { x: 540, y: 710.4 };
  const RADIUS = 456.84;
  const defaults = {
    showHands: true,
    handColor: "#ffffff",
    handThickness: 8,
    markerMode: "dashes",
    markerColor: "#ffffff",
    markerVariant: "classic",
    markerWeight: 4,
    dateColor: "#ffffff",
    dateVariant: "classic",
    dateWeight: 6
  };

  let settings = { ...defaults };
  let designs = [];
  let currentIndex = 0;
  let lastClockUpdate = 0;
  const svgNamespace = "http://www.w3.org/2000/svg";
  const clockPreview = document.getElementById("clockPreview");
  const hourHand = document.getElementById("hourHand");
  const minuteHand = document.getElementById("minuteHand");
  const secondHand = document.getElementById("secondHand");
  const centerDot = document.getElementById("centerDot");
  const markers = document.getElementById("markers");
  const hands = document.getElementById("hands");
  const dayText = document.getElementById("dayText");
  const dateText = document.getElementById("dateText");

  const timeFormatter = new Intl.DateTimeFormat("en-US", {
    timeZone: TIME_ZONE,
    hour: "numeric",
    minute: "numeric",
    second: "numeric",
    hourCycle: "h23"
  });
  const dayFormatter = new Intl.DateTimeFormat("en-US", { timeZone: TIME_ZONE, weekday: "long" });
  const dateFormatter = new Intl.DateTimeFormat("en-US", {
    timeZone: TIME_ZONE,
    month: "long",
    day: "numeric",
    year: "numeric"
  });

  function zonedTimeParts(now) {
    const values = {};
    for (const part of timeFormatter.formatToParts(now)) {
      if (part.type !== "literal") {
        values[part.type] = Number(part.value);
      }
    }
    return values;
  }

  function handAngles(now) {
    const parts = zonedTimeParts(now);
    const seconds = parts.second + now.getMilliseconds() / 1000;
    const minutes = parts.minute + seconds / 60;
    const hours = (parts.hour % 12) + minutes / 60;
    return {
      hour: hours * 30,
      minute: minutes * 6,
      second: seconds * 6
    };
  }

  function updateClock() {
    const now = new Date();
    const angles = handAngles(now);
    hourHand.setAttribute("transform", `rotate(${angles.hour} ${CENTER.x} ${CENTER.y})`);
    minuteHand.setAttribute("transform", `rotate(${angles.minute} ${CENTER.x} ${CENTER.y})`);
    secondHand.setAttribute("transform", `rotate(${angles.second} ${CENTER.x} ${CENTER.y})`);
    hourHand.dataset.angle = angles.hour.toFixed(6);
    minuteHand.dataset.angle = angles.minute.toFixed(6);
    secondHand.dataset.angle = angles.second.toFixed(6);
    clockPreview.dataset.timeZone = TIME_ZONE;
    clockPreview.dataset.localTime = timeFormatter.format(now);
    dayText.textContent = dayFormatter.format(now).toUpperCase();
    dateText.textContent = dateFormatter.format(now);
  }

  function renderSettings() {
    const handThickness = Math.max(2, Number(settings.handThickness) || 8);
    hands.style.stroke = settings.handColor;
    hands.style.opacity = settings.showHands ? "1" : "0";
    centerDot.style.fill = settings.handColor;
    centerDot.style.opacity = settings.showHands ? "1" : "0";
    hourHand.setAttribute("stroke-width", handThickness);
    minuteHand.setAttribute("stroke-width", Math.max(2, handThickness * 0.72));
    secondHand.setAttribute("stroke-width", Math.max(1, handThickness * 0.38));
    centerDot.setAttribute("r", handThickness * 1.4);

    const markerWeight = Math.max(1, Number(settings.markerWeight) || 4);
    const variantScale = { classic: 1, fine: 0.62, bold: 1.34, rounded: 1.08 }[settings.markerVariant] || 1;
    markers.replaceChildren();
    for (let hour = 1; hour <= 12; hour += 1) {
      const angle = hour * 30;
      const radians = (angle - 90) * Math.PI / 180;
      if (settings.markerMode === "numbers") {
        const label = document.createElementNS(svgNamespace, "text");
        label.textContent = String(hour);
        label.setAttribute("x", CENTER.x + Math.cos(radians) * RADIUS);
        label.setAttribute("y", CENTER.y + Math.sin(radians) * RADIUS);
        label.setAttribute("text-anchor", "middle");
        label.setAttribute("dominant-baseline", "middle");
        label.setAttribute("fill", settings.markerColor);
        label.setAttribute("font-size", (1015.2 * (0.052 + markerWeight * 0.004) * variantScale).toFixed(2));
        label.setAttribute("font-weight", settings.markerVariant === "fine" ? "400" : "700");
        markers.appendChild(label);
      } else if (settings.markerMode === "dashes") {
        const dash = document.createElementNS(svgNamespace, "line");
        dash.setAttribute("x1", CENTER.x + Math.cos(radians) * RADIUS * 0.86);
        dash.setAttribute("y1", CENTER.y + Math.sin(radians) * RADIUS * 0.86);
        dash.setAttribute("x2", CENTER.x + Math.cos(radians) * RADIUS * 0.99);
        dash.setAttribute("y2", CENTER.y + Math.sin(radians) * RADIUS * 0.99);
        dash.setAttribute("stroke", settings.markerColor);
        dash.setAttribute("stroke-width", Math.max(1, markerWeight * 0.8 * variantScale));
        dash.setAttribute("stroke-linecap", settings.markerVariant === "rounded" ? "round" : "butt");
        markers.appendChild(dash);
      }
    }

    const dateWeight = Math.max(1, Number(settings.dateWeight) || 6);
    dayText.style.fill = settings.dateColor;
    dateText.style.fill = settings.dateColor;
    dayText.style.fontWeight = settings.dateVariant === "fine" ? "400" : "700";
    dayText.style.fontSize = `${Math.min(62.1, 40 + dateWeight * 4)}px`;
    dateText.style.fontSize = `${Math.min(40.2, 24 + dateWeight * 2)}px`;
  }

  function renderDesign() {
    const design = designs[currentIndex];
    settings = { ...defaults, ...(design?.settings || {}) };
    clockPreview.dataset.activeDesign = design?.name || "Sample Clock";
    renderSettings();
  }

  function moveDesign(offset) {
    if (!designs.length) {
      return;
    }
    currentIndex = (currentIndex + offset + designs.length) % designs.length;
    renderDesign();
  }

  async function loadDesign() {
    try {
      const response = await fetch("../library/playlist.json", { cache: "no-store" });
      const playlist = await response.json();
      const byId = new Map((playlist.designs || []).map((design) => [design.id, design]));
      designs = (playlist.designOrder || []).map((id) => byId.get(id)).filter(Boolean);
      if (!designs.length) {
        designs = playlist.designs || [];
      }
    } catch (_error) {
      designs = [];
    }
    renderDesign();
    updateClock();
  }

  document.addEventListener("keydown", (event) => {
    if (event.key === "ArrowLeft") {
      moveDesign(-1);
    } else if (event.key === "ArrowRight" || event.key === " ") {
      moveDesign(1);
    }
  });

  function animationLoop(timestamp) {
    if (timestamp - lastClockUpdate >= 1000 / 30) {
      updateClock();
      lastClockUpdate = timestamp;
    }
    window.requestAnimationFrame(animationLoop);
  }

  loadDesign();
  window.requestAnimationFrame(animationLoop);
})();
