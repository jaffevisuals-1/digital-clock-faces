# Pi Clock Player

Native Raspberry Pi display app for the Digital Animation Clock. This replaces
the Chromium kiosk path with a fullscreen Python/Kivy player.

## What It Does

- Runs fullscreen on the Pi's attached display.
- Loads `playlist.json` plus normal media files from a local library folder.
- Starts on a random clock design, then rotates by each design's duration.
- Plays the circular clock video and optional date-rectangle video.
- Draws clock hands, markers, date, and day as native overlays.
- Keeps using the last working local playlist if sync fails.
- Applies a newly published playlist immediately and opens the design selected
  in the companion.

## Pi Install

Copy this folder to the Pi, then run:

```bash
cd PiClockPlayer
bash scripts/setup_pi.sh
```

Manual launch:

```bash
~/clock-player/app/scripts/start_player.sh
```

For a 16:9 monitor mounted vertically, set the Pi display orientation to
portrait in Raspberry Pi OS, then launch normally. The player automatically
defaults to portrait mode and uses an internal 90-degree app rotation if the
Pi desktop still reports a landscape framebuffer:

```bash
~/clock-player/app/scripts/start_player.sh
```

Try to rotate the Pi desktop output and set the app fallback rotation:

```bash
~/clock-player/app/scripts/set_display_portrait.sh 90
~/clock-player/app/scripts/restart_player.sh
```

If the mounted screen is upside down, use:

```bash
~/clock-player/app/scripts/set_display_portrait.sh 270
~/clock-player/app/scripts/restart_player.sh
```

To force portrait dimensions while using fixed window mode:

```bash
CLOCK_PLAYER_ORIENTATION=portrait CLOCK_PLAYER_ROTATION=90 CLOCK_PLAYER_WINDOW_MODE=1 ~/clock-player/app/scripts/start_player.sh
```

The default launch uses Kivy fullscreen. To test a normal desktop window:

```bash
CLOCK_PLAYER_WINDOWED=1 ~/clock-player/app/scripts/start_player.sh
```

Preview the native player on a Mac in a portrait window:

```bash
PiClockPlayer/scripts/preview_on_mac.sh
```

To force the older borderless 1024 x 600 window mode instead:

```bash
CLOCK_PLAYER_WINDOW_MODE=1 ~/clock-player/app/scripts/start_player.sh
```

If the clock content is too close to the edge of the physical display, shrink
the safe drawing area:

```bash
CLOCK_PLAYER_SAFE_SCALE=0.72 ~/clock-player/app/scripts/start_player.sh
```

Preflight check on the Pi:

```bash
~/clock-player/app/scripts/check_pi_runtime.sh
```

Deploy from your Mac in one shot:

```bash
PiClockPlayer/scripts/deploy_to_pi.sh epjaffe@Ethan-Pi.local
```

Restart after copying new files:

```bash
~/clock-player/app/scripts/restart_player.sh
```

## Library Format

The player reads:

```text
~/clock-player/library/playlist.json
~/clock-player/library/media/example.mp4
```

The browser companion's **Export Pi Folder** button creates this shape:

```text
playlist.json
media/
  clock-face-clock-abc123.mp4
  clock-face-date-def456.mp4
```

Copy that folder's contents into `~/clock-player/library/` on the Pi.

From your Mac, sync an exported Pi folder directly to the Pi:

```bash
PiClockPlayer/scripts/sync_library_to_pi.sh /path/to/exported-pi-folder epjaffe@Ethan-Pi.local
```

## Cloud Sync

The recommended no-card connection is a public GitHub repository. The Pi stores
no GitHub credentials. Before pairing, run the one-time connectivity gate copied
by the Mac setup:

```bash
~/clock-player/app/scripts/check_cloud_sync.sh https://raw.githubusercontent.com/USER/digital-clock-faces/main/
```

This must successfully download `connectivity-check.txt` before it changes the
Pi configuration. If GitHub downloads are blocked, use a dedicated travel
router; do not fall back to temporary public tunnels.

After pairing, the Pi checks `playlist.json` every 15 seconds and immediately
switches to the design that was selected when **Publish to Clock** was clicked.
Schema-2 packages
include byte counts and SHA-256 checksums. The player downloads into staging,
validates every referenced file, and atomically swaps the library only after the
complete release passes. The previous release remains available after any
network, missing-file, size, or checksum failure.

Clock videos are converted by the Mac companion to a 12 fps Kivy ZIP image
sequence. The first 6 seconds are used and loop continuously, keeping memory
use predictable on smaller Pi models. Player software updates are separate from
clockface publishing.

## Manual Face Controls

Use the translucent on-screen arrows or the keyboard left/right arrow keys.
External buttons and future remotes can call:

```bash
~/clock-player/app/scripts/previous_face.sh
~/clock-player/app/scripts/next_face.sh
```

## Legacy Sync

Configure sync in:

```text
~/.config/clock-player/config.json
```

For local-network folder sync, set:

```json
{
  "libraryDir": "/home/epjaffe/clock-player/library",
  "sync": {
    "enabled": true,
    "source": "/home/epjaffe/clock-sync",
    "intervalSeconds": 300
  }
}
```

For legacy HTTP sync, `source` can be a URL containing `playlist.json` and media.

Pair the player with the Mac companion once:

```bash
~/clock-player/app/scripts/configure_companion_sync.sh http://YOUR-MAC:4176/sync/
```

The player checks every 15 seconds on a background thread. New packages are
downloaded to a staging folder, verified, swapped into place atomically, and
applied without restarting the player. The previous working package remains
available if a transfer fails.

## Boot

`setup_pi.sh` enables the player as a user service and also installs a desktop
login launcher. The login launcher refreshes the graphical-session settings and
restarts the same service, so only one player runs. Both paths use the saved
portrait configuration and apply clockwise 90-degree rotation on every launch.
The installer also enables user-service lingering and an always-restart policy,
so the player starts after a power cycle and keeps retrying until the display
session is ready.

To repair or reinstall startup on an existing Pi:

```bash
~/clock-player/app/scripts/install_user_service.sh
```
